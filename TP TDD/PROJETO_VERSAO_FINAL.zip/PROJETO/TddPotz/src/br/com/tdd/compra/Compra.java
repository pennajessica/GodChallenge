package br.com.tdd.compra;

import java.io.Console;

import br.com.tdd.potz.Potz;

class Compra {
	
	 public static void main(String[] args){ 
		String cupom = "5001234560";
		Potz pt1 = new Potz(cupom);
		if(pt1.isValido())
			System.out.println("Voc� Ganhou: " + pt1.pontosObtidos() + " Potz");
		else
			System.out.println("Cupom Potz Inv�lido");
	}

}
